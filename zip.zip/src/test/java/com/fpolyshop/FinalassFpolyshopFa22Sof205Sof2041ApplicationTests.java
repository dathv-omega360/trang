package com.fpolyshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinalassFpolyshopFa22Sof205Sof2041ApplicationTests {

	@Test
	void contextLoads() {
	}

}
