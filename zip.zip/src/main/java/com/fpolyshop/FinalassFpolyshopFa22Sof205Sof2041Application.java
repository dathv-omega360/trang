package com.fpolyshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinalassFpolyshopFa22Sof205Sof2041Application {

	public static void main(String[] args) {
		SpringApplication.run(FinalassFpolyshopFa22Sof205Sof2041Application.class, args);
	}

}
